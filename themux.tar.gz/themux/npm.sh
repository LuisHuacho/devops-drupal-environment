npm init -y
npm install laravel-mix --save-dev
npm install cross-env --save-dev
