module Bootstrap
  VERSION       = '3.4.1'
  BOOTSTRAP_SHA = '68b0d231a13201eb14acd3dc84e51543d16e5f7e'
end
